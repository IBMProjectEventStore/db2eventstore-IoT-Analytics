"""
This module implements the Spark/OLAP functionality of the IBM Event Store.
"""
from py4j.java_gateway import java_import
from pyspark.sql.session import SparkSession
from eventstore.sql.session import SparkSession


class ConfigurationReader(object):
    """
    """
    _jCR = None
    # python ConfigurationReader's cached setter values
    py_connectionEndpoints = None
    py_legacyConnectionEndpoints = None
    py_connectionTimeout = None
    py_connectionAckTimeout = None
    py_connectionRetry = None
    py_esUser = None
    py_outputFile = None
    py_esPassword = None
    py_caseSensitive = None
    py_internalUser = None
    py_storageType = None
    py_useFrontend = None
    py_eventToken = None
    py_queryTimeout = None
    py_allowJoinPushDowns = None
    py_allowPrintSiQLQueriesIsSet = None
    py_loggerLevels = {}

    # python ConfigurationReader's cached readonly values
    py_ensembleServerList = None
    py_zkEnsembleString = None
    py_trustStoreLocation = None
    py_trustStorePassword = None
    py_keyStoreLocation = None
    py_keyStorePassword = None
    py_pluginName = None
    py_plugin = None
    py_schemaName = None
    py_sslEnabled = None
    py_inlistNLJOIN = None
    py_jdbcConfig = None


    #default values to be kept in-sync with Scala's configurationReader
    BLUSPARK_CONF = "bluspark.conf"
    DefaultPrintSiQLQuery = False
    DefaultForClientConnectionRetry = 0
    DefaultForClientConnectionAckTimeout = 10
    DefaultForRollerFrequency = 600
    DefaultLoggerLevel = "WARN"
    DefaultForClientConnectionTimeout = 2

    # configuration parameters (keys entries in bluspark.conf)
    # ZK_CONN_STRING = "zookeeper.connectionString"
    # CLIENT_CONN_ENDPTS = "internal.client.connection.endpoints"
    # CLIENT_CONN_TIMEOUT = "internal.client.connection.timeout" # In minutes
    # CLIENT_CONN_ACK_TIMEOUT = "internal.client.connection.ackTimeout"
    # CLIENT_CONN_RETRY = "internal.client.connection.retry" # Int
    # HIVE_METASTORE_URIS = "internal.hive.metastore.uris"
    # HIVE_METASTORE_DB = "internal.hive.metastore.database"
    # ROLLER_FREQUENCY = "internal.roller.frequency" # In seconds
    # PRINT_SIQL_QUERY = "internal.client.print.siql"
    # BLUSPARK_LOGGER_LEVEL = "trace.defaultVerbosity"
    # CLIENT_ALLOW_JOINPD = "internal.client.allowJoinPushDowns"
    # SSL_ENABLED = "security.SSLEnabled" (converted to reg var DB2_ES_SECURITY_SSLENABLED)

    def __init__(self):
        """
        object constructor currently not used
        """
    # No setter for this
    @classmethod
    def ensembleServerList(cls):
        """
        ensembleServerList is a scala val and so, immutable
        :return: immutable list of connectionEndpoints
        """

        if cls._jCR :
            try:
                cls.py_ensembleServerList = cls._jCR.ensembleServerList()
            except Exception:
                return None
        return cls.py_ensembleServerList


    # No setter for this
    @classmethod
    def zkEnsembleString(cls):
        """
        """
        if cls._jCR :
            try:
                cls.py_zkEnsembleString = cls._jCR.zkEnsembleString()
            except Exception:
                return None
        return cls.py_zkEnsembleString

    @classmethod
    def setupFromDatasource(cls, data_source, scala_url):
        URL = data_source['URL'][len("jdbc:db2://"):]
        DB2IP = (URL[0:URL.find('/')])
        # extract SSL information in lists
        URL_splited_list = URL.replace(" ", "").replace(":", ";").split(";")
        pluginName_list = [x for x in URL_splited_list if 'pluginName' in x]
        trustStoreLoc_list = [x for x in URL_splited_list if 'sslTrustStoreLocation' in x]
        trustStorePwd_list = [x for x in URL_splited_list if 'sslTrustStorePassword' in x]
        if len(pluginName_list) > 0:
            cls.setClientPluginName(pluginName_list[0].split("=", 1)[1])
        # keystore is same as truststore
        if len(trustStoreLoc_list) > 0:
            assert len(trustStorePwd_list) > 0, \
                "sslTrustStorePassword must be provided in the presence of sslTrustStoreLocation"
            cls.setSslTrustStoreLocation(trustStoreLoc_list[0].split("=", 1)[1])
            cls.setSslTrustStorePassword(trustStorePwd_list[0].split("=", 1)[1])
            cls.setSslKeyStoreLocation(trustStoreLoc_list[0].split("=", 1)[1])
            cls.setSslKeyStorePassword(trustStorePwd_list[0].split("=", 1)[1])
        cls.setConnectionEndpoints(DB2IP + ";" + scala_url)
        cls.setEventPassword(data_source['password'])
        cls.setEventUser(data_source['user'])

    @classmethod
    def setConnectionTimeout(cls, connTimeout):
        """
	* embleStringefault client timeout is 2 mins.
    	* For timeout < 2 min, default timeout 2 mins is set.
        """
        # cache the setting
        if connTimeout < cls.DefaultForClientConnectionTimeout:
           cls.py_connectionTimeout = cls.DefaultForClientConnectionTimeout
        else:
           cls.py_connectionTimeout = connTimeout

        if cls._jCR :
            cls._jCR.setConnectionTimeout( connTimeout )

    @classmethod
    def setOutputFile(cls, outputFile):
        """
        """
        # cache the setting
        cls.py_outputFile = outputFile
        if cls._jCR :
            cls._jCR.setOutputFile(outputFile)

    @classmethod
    def setConnectionAckTimeout(cls, connTimeout):
        """
        """
        # cache the setting
        cls.py_connectionAckTimeout = connTimeout
        if cls._jCR :
            cls._jCR.setConnectionAckTimeout( connTimeout )

    @classmethod
    def setConnectionRetry(cls, connRetry):
        """
        """
        # cache the setting
        cls.py_connectionRetry = connRetry
        if cls._jCR :
            cls._jCR.setConnectionRetry( connRetry )

    @classmethod
    def setConnectionEndpoints(cls, c_str):
        """
        """
        # update the local CR cache
        cls.py_connectionEndpoints = c_str
        if cls._jCR :
            # send the endpoint to CR
            cls._jCR.setConnectionEndpoints(c_str)

    @classmethod
    def getConnectionEndpoints(cls):
        """
        :return: connectionEndpoints
        """
        if cls._jCR :
            # if we have the gateway to scala CR, re-fetch the endpoint
            cls.py_connectionEndpoints = cls._jCR.getConnectionEndpoints()
        if  cls.py_connectionEndpoints :
            return  cls.py_connectionEndpoints
        return cls.py_connectionEndpoints

    @classmethod
    def setEventUser(cls, userString):
        """
        """
        # update the local CR cache
        cls.py_esUser = userString
        if cls._jCR :
            # send the userString to CR
            cls._jCR.setEventUser(userString)

    @classmethod
    def setStorageType(cls, storageType):
        """
        """
        cls.py_storageType = storageType
        if cls._jCR :
            cls._jCR.setStorageType(storageType)

    @classmethod
    def setLoggerLevel(cls, logger_name, level):
        """
        """
        cls.py_loggerLevels[logger_name] = level
        if cls._jCR :
            cls._jCR.setLoggerLevel(logger_name, level)


    @classmethod
    def setEventPassword(cls, passwordString):
        """
        """
        # update the local CR cache
        cls.py_esPassword = passwordString
        if cls._jCR :
            # send the passwordString to CR
            cls._jCR.setEventPassword(passwordString)

    @classmethod
    def setSSLEnabled(cls, sslFlag):
        """
        """
        # update the local CR cache
        cls.py_sslEnabled = sslFlag
        if cls._jCR :
            cls._jCR.setSSLEnabled(sslFlag)


    @classmethod
    def setEventSchemaName(cls, name):
        """
        """
        # update the local CR cache
        cls.py_schemaName = name
        if cls._jCR :
            cls._jCR.setEventSchemaName(name)


    @classmethod
    def setCaseSensitive(cls, caseSensitive):
        """
        """
        # update the local CR cache
        cls.py_caseSensitive = caseSensitive
        if cls._jCR :
            cls._jCR.setCaseSensitive(caseSensitive)


    @classmethod
    def setUseFrontendConnectionEndpoints(cls, useFrontend):
        """
        """
        # update the local CR cache
        cls.py_useFrontend = useFrontend
        if cls._jCR :
            cls._jCR.setUseFrontendConnectionEndpoints(useFrontend)

    @classmethod
    def setInternalUser(cls, internalUser):
        """
        """
        # update the local CR cache
        cls.py_internalUser = internalUser
        if cls._jCR :
            cls._jCR.setInternalUser(internalUser)

    @classmethod
    def setAllowJoinPushDowns(cls, allowJoinPD):
        """
        """
        # update the local CR cache
        cls.py_allowJoinPushDowns = allowJoinPD
        if cls._jCR :
            cls._jCR.setAllowJoinPushDowns(allowJoinPD)

    @classmethod
    def setAlloPrintSiQLQueries(cls, allowPrintSiQL):
        """
        """
        # update the local CR cache
        cls.py_allowPrintSiQLQueriesIsSet = True
        if cls._jCR :
            cls._jCR.setAlloPrintSiQLQueries(allowPrintSiQL)

    @classmethod
    def setSslTrustStoreLocation(cls, trustLocation):
        """
        """
        # update the local CR cache
        cls.py_trustStoreLocation = trustLocation
        if cls._jCR :
            # send the trustLocation to CR
            cls._jCR.setSslTrustStoreLocation(trustLocation)

    @classmethod
    def setSslTrustStorePassword(cls, trustPassword):
        """
        """
        # update the local CR cache
        cls.py_trustStorePassword = trustPassword
        if cls._jCR :
            # send the trustPassword to CR
            cls._jCR.setSslTrustStorePassword(trustPassword)

    @classmethod
    def setSslKeyStoreLocation(cls, keyLocation):
        """
        """
        # update the local CR cache
        cls.py_keyStoreLocation = keyLocation
        if cls._jCR :
            # send the keyLocation to CR
            cls._jCR.setSslKeyStoreLocation(keyLocation)

    @classmethod
    def setSslKeyStorePassword(cls, keyPassword):
        """
        """
        # update the local CR cache
        cls.py_keyStorePassword = keyPassword
        if cls._jCR :
            # send the keyPassword to CR
            cls._jCR.setSslKeyStorePassword(keyPassword)

    @classmethod
    def setClientPluginName(cls, pluginName):
        """
        """
        # update the local CR cache
        cls.py_pluginName = pluginName
        if cls._jCR :
            # send the pluginName to CR
            cls._jCR.setClientPluginName(pluginName)

    @classmethod
    def setClientPlugin(cls, plugin):
        """
        """
        # update the local CR cache
        cls.py_plugin = plugin
        if cls._jCR :
            # send the Plugin flag to CR
            cls._jCR.setClientPlugin(plugin)

    @classmethod
    def setInListConversion(cls, inlist):
        """
        """
        # update the local CR cache
        cls.py_inlistNLJOIN = inlist
        if cls._jCR:
            cls._jCR.setInListConversion(inlist)

    @classmethod
    def setJDBCConfiguration(cls, configStr):
        """
        """
        # update the local CR cache
        cls.py_jdbcConfig = configStr
        if cls._jCR:
            cls._jCR.setJDBCConfiguration(configStr)

    @classmethod
    def getSslTrustStoreLocation(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_trustStoreLocation = cls._jCR.getSslTrustStoreLocation()

        if cls.py_trustStoreLocation :
            return cls.py_trustStoreLocation

    @classmethod
    def getSslTrustStorePassword(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_trustStorePassword = cls._jCR.getSslTrustStorePassword()

        if cls.py_trustStorePassword :
            return cls.py_trustStorePassword

    @classmethod
    def getSslKeyStoreLocation(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_keyStoreLocation = cls._jCR.getSslKeyStoreLocation()

        if cls.py_keyStoreLocation :
            return cls.py_keyStoreLocation

    @classmethod
    def getSslKeyStorePassword(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_KeyStorePassword = cls._jCR.getSslKeyStorePassword()

        if cls.py_KeyStorePassword :
            return cls.py_KeyStorePassword

    @classmethod
    def getClientPluginName(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_pluginName = cls._jCR.getClientPluginName()

        if cls.py_pluginName :
            return cls.py_pluginName

    @classmethod
    def getClientPlugin(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_plugin = cls._jCR.getClientPlugin()

        if cls.py_plugin :
            return cls.py_plugin

    @classmethod
    def getSSLEnabled(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_sslEnabled = cls._jCR.getSSLEnabled()

        if cls.py_sslEnabled :
            return cls.py_sslEnabled
        return False


    @classmethod
    def getEventSchemaName(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_schemaName = cls._jCR.getEventSchemaName()

        if cls.py_schemaName :
            return cls.py_schemaName


    @classmethod
    def getEventUser(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_esUser = cls._jCR.getEventUser()

        if cls.py_esUser :
            return cls.py_esUser
        return ""

    @classmethod
    def getQueryTimeout(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_queryTimeout = cls._jCR.getQueryTimeout()

        if cls.py_queryTimeout :
            return cls.py_queryTimeout
        return ""

    @classmethod
    def allowInListConversion(cls):
        """
        """
        if cls._jCR:
            # we have the gateway to scala CR
            cls.py_inlistNLJOIN = cls._jCR.allowInListConversion()
            print(cls.py_inlistNLJOIN)

        if cls.py_inlistNLJOIN:
            return cls.py_inlistNLJOIN
        return False

    @classmethod
    def getJDBCConfiguration(cls):
        """
        """
        if cls._jCR:
            # we have the gateway to scala CR
            cls.py_jdbcConfig = cls._jCR.getJDBCConfiguration()

        if cls.py_jdbcConfig:
            return cls.py_jdbcConfig
        return ""


    @classmethod
    def setEventStoreToken(cls, eventToken):
        """
        """
        # update the local CR cache
        cls.py_eventToken = eventToken
        if cls._jCR :
            cls._jCR.setEventStoreToken(eventToken)

    @classmethod
    def setQueryTimeout(cls, queryTimeout):
        """
        """
        # update the local CR cache
        cls.py_queryTimeout = queryTimeout
        if cls._jCR :
            cls._jCR.setQueryTimeout(queryTimeout)
    """
    Getters with no setters, values set in bluspark.conf
    """

    @classmethod
    def hiveMetastoreURIS(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.hiveMetastoreURIS()
        return ""

    @classmethod
    def hiveMetastoreDB(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.hiveMetastoreDB()
        return ""

    @classmethod
    def getLegacySecurityToken(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.getLegacySecurityToken()
        return ""


    @classmethod
    def getSecurityToken(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.getSecurityToken()
        return ""



    @classmethod
    def blusparkLoggerLevel(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.blusparkLoggerLevel()
        return cls.DefaultLoggerLevel

    @classmethod
    def getJDBCConnection(cls, conn):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.getJDBCConnection(conn)
        return None

    @classmethod
    def rollerFrequency(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.rollerFrequency()
        return cls.DefaultForRollerFrequency

    @classmethod
    def getConnectionTimeout(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_connectionTimeout = cls._jCR.getConnectionTimeout()

        if cls.py_connectionTimeout :
            return cls.py_connectionTimeout
        return cls.DefaultForClientConnectionTimeout


    @classmethod
    def getConnectionAckTimeout(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_connectionAckTimeout = cls._jCR.getConnectionAckTimeout()
        if cls.py_connectionAckTimeout :
            return cls.py_connectionAckTimeout
        return cls.DefaultForClientConnectionAckTimeout

    @classmethod
    def getConnectionRetry(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_connectionRetry = cls._jCR.getConnectionRetry()
        if cls.py_connectionRetry :
            return  cls.py_connectionRetry
        return cls.DefaultForClientConnectionRetry

    @classmethod
    def getGitRevision(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            return cls._jCR.getGitRevision()
        return "Connect to EventContext or EventSession first"

    @classmethod
    def printSiQLQueryString(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_allowPrintSiQLQueriesIsSet = cls._jCR.printSiQLQueryString()
        if cls.py_allowPrintSiQLQueriesIsSet :
            return  cls.py_allowPrintSiQLQueriesIsSet
        return cls.DefaultPrintSiQLQuery

    @classmethod
    def SSLEnabled(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_sslEnabled = cls._jCR.SSLEnabled()
        if cls.py_sslEnabled:
            return  cls.py_sslEnabled
        return True

    @classmethod
    def allowJoinPushDownsValuelientUser(cls):
        """
        """
        if cls._jCR :
            # we have the gateway to scala CR
            cls.py_allowJoinPushDowns = cls._jCR.allowJoinPushDownsValue()
        if cls.py_allowJoinPushDowns :
            return cls.py_allowJoinPushDowns
        return False

    @classmethod
    def updateScalaConfigReader(cls):
        """
        flush any Python CR settings to Scala's CR
        """
        if cls._jCR :
            # no setters for:
            # cls.py_ensembleServerList
            # cls.py_zkEnsembleString
            if cls.py_connectionEndpoints :
               cls._jCR.setConnectionEndpoints(cls.py_connectionEndpoints)
            if cls.py_legacyConnectionEndpoints :
               cls._jCR.setLegacyConnectionEndpoints(cls.py_legacyConnectionEndpoints)
            if cls.py_connectionTimeout :
               cls._jCR.setConnectionTimeout(cls.py_connectionTimeout)
            if cls.py_connectionAckTimeout :
               cls._jCR.setConnectionAckTimeout( cls.py_connectionAckTimeout )
            if cls.py_connectionRetry :
               cls._jCR.setConnectionRetry( cls.py_connectionRetry )
            if cls.py_sslEnabled :
               cls._jCR.setSSLEnabled(cls.py_sslEnabled)
            if cls.py_allowJoinPushDowns :
               cls._jCR.setAllowJoinPushDowns(cls.py_allowJoinPushDowns)
            if cls.py_allowPrintSiQLQueriesIsSet :
               cls._jCR.setAlloPrintSiQLQueries(cls.py_allowPrintSiQLQueriesIsSet)
            if cls.py_caseSensitive :
               cls._jCR.setCaseSensitive(cls.py_caseSensitive)
            if cls.py_internalUser :
               cls._jCR.setInternalUser(cls.py_internalUser)
            if cls.py_useFrontend:
               cls._jCR.setUseFrontendConnectionEndpoints(cls.py_useFrontend)
            if cls.py_eventToken :
               cls._jCR.setEventStoreToken(cls.py_eventToken)
            if cls.py_queryTimeout :
               cls._jCR.setQueryTimeout(cls.py_queryTimeout)
            if cls.py_loggerLevels:
               for loggerName in cls.py_loggerLevels:
                   cls._jCR.setLoggerLevel(loggerName, cls.py_loggerLevels[loggerName])
            if cls.py_esUser :
               cls._jCR.setEventUser(cls.py_esUser)
            if cls.py_esPassword :
               cls._jCR.setEventPassword(cls.py_esPassword)
            if cls.py_trustStoreLocation :
                cls._jCR.setSslTrustStoreLocation(cls.py_trustStoreLocation)
            if cls.py_trustStorePassword :
                cls._jCR.setSslTrustStorePassword(cls.py_trustStorePassword)
            if cls.py_keyStoreLocation :
                cls._jCR.setSslKeyStoreLocation(cls.py_keyStoreLocation)
            if cls.py_keyStorePassword :
                cls._jCR.setSslKeyStorePassword(cls.py_keyStorePassword)
            if cls.py_storageType :
                cls._jCR.setStorageType(cls.py_storageType)
            if cls.py_pluginName :
                cls._jCR.setClientPluginName(cls.py_pluginName)
            if cls.py_outputFile :
                cls._jCR.setOutputFile(cls.py_outputFile)
            if cls.py_plugin :
                cls._jCR.setClientPlugin(cls.py_plugin)
            if cls.py_schemaName :
                cls._jCR.setEventSchemaName(cls.py_schemaName)
            if cls.py_inlistNLJOIN :
                cls._jCR.setInListConversion(cls.py_inlistNLJOIN)
            if cls.py_jdbcConfig :
                cls._jCR.setJDBCConfiguration(cls.py_jdbcConfig)

