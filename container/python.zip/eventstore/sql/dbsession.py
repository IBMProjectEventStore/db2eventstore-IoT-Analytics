"""
This module implements the Spark/OLAP functionality of IBM DB2.
"""
from py4j.java_gateway import java_import
from pyspark.sql import SparkSession, DataFrame
import eventstore.common


class DbSparkSession(SparkSession):
    """
    The Spark SQL entry point to IBM DB2 spark client API.

    :param spark_context: a Python :class:`pyspark.SparkContext`
    :param database_name: database name to which bind this session is bound

    In DbSparkSession is created from a SparkContext, which,
    in turn can be obtained from a SparkSession. An DbSparkSession is a
    SparkSession with the following additional methods:

    - .. py:method:: open_database()
    - .. py:function:: load_table(table_name)

    An example:

    >>> from pyspark.sql import SparkSession
    >>> sparkSession = SparkSession.builder \\
    ...                            .appName("IBM Db2 SQL in Python") \\
    ...                            .getOrCreate()
    >>> dbSession = DbSparkSession(sparkSession.sparkContext, "TestDB")
    >>> dbSession.open_database()
    >>> dbSession.load_table("Reviews") \\
    ...             .createOrReplaceTempView("Reviews")
    >>> df = dbSession.sql("SELECT * FROM Reviews")
    """

    #: The Py4J gateway into the JVM
    _gateway = None

    def __init__(self, spark_context, database_name):
        DbSparkSession._ensure_initialized(spark_context._gateway)

        # if there are any ConfigurationReader settings, push it down to scala
        # before the rest of the initializtion code uses the settings
        #ok:eventstore.common.ConfigurationReader._jCR = SparkSession._instantiatedContext._jvm.ConfigurationReader
        eventstore.common.ConfigurationReader._jCR = spark_context._jvm.ConfigurationReader
        eventstore.common.ConfigurationReader.updateScalaConfigReader()

        self._spark_context = spark_context
        self._database_name = database_name

        # spark_context is the Python SparkContext
        # spark_context._jsc is the JavaSparkContext
        # spark_context._jsc.sc() returns the actual Scala SparkContext
        self._jsc = spark_context._jsc.sc()
        self._jvm = spark_context._jvm
        self._jes = self._jvm.DbSparkSession(self._jsc, database_name)
        super(DbSparkSession, self).__init__(spark_context, self._jes)

    def open_database(self):
        """
        Open the database in this session.

        :return: nothing or an exception
        """
        self._jes.openDatabase()

    def load_table(self, table_name, schema_name=None):
        """
        Load table from IBM Db2 into DataFrame.

        :param table_name: name of the table to load.
        :return: A :class:`pyspark.sql.DataFrame`
        """
        if schema_name is None:
            jdf = self._jes.loadTable(table_name)
        else:
            jdf = self._jes.loadTable(table_name, schema_name)

        return DataFrame(jdf, self._wrapped)

    def set_sql_config_string(self, key, value):
        self._jes.setSQLConfString(key, value)

    def get_sql_config_string(self, key):
        return self._jes.getSQLConfString(key)

    def set_query_read_option(self, opt):
        """
        Set a query read option to be used by subsequent queries in this session to set isolation level.

        A query read option indicates the level of read consistency required.  A
        strict consistency like SnapshotNow will get the most
        consistent data but may have to wait for the latest data to be made
        available.  The other levels are not as strict so would not incur the
        wait but might not have the most recently inserted data
        (SnapshotAny) or could contain duplicate rows (SnapshotNone).

        :param opt: Read option to use in the session
        :type opt: SnapshotNow, SnapshotAny, or SnapshotNone
        """
        self._jes.setQueryReadOption(opt)

    def get_query_read_option(self):
        """
        Return the session's current read option

        :return String representation of the current query read option
        """
        return self._jes.getQueryReadOptionAsString()

    @classmethod
    def _ensure_initialized(cls, gateway):
        if not cls._gateway:
            java_import(gateway.jvm, "com.ibm.event.catalog.*")
            java_import(gateway.jvm, "com.ibm.event.sql.*")
            java_import(gateway.jvm, "com.ibm.event.common.*")
            java_import(gateway.jvm, "org.apache.spark.sql.ibm.event.*")
            java_import(gateway.jvm, "org.apache.spark.sql.ibm.db.*")

            cls._gateway = gateway
