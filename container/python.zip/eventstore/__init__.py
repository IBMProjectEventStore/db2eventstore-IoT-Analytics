"""
Python API for IBM Event Store
"""
