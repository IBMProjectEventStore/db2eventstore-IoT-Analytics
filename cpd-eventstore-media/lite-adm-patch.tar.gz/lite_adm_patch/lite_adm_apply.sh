#!/bin/bash

# This script is a manual patch for using cpd-cli in CPD 4.0.0
# It will apply cpd-cli required adm resources, After this script being executed,
# you are able to use cpd-cli to install db2eventstore addons. 

##########
#Functions
#########

function _log()       { echo -e "[`date`]$1"; }
function log_info()   { _log "[INFO] \e[34m$1\e[39m"; }
function log_passed() { _log "[PASSED] \e[32m$1\e[39m"; }
function log_warn()   { _log "[WARN] \e[33m$1\e[39m"; }
function log_error()  { _log "[ERROR] \e[31m$1\e[39m" >&2; }

function usage()
{
cat <<-USAGE #| fmt
Usage: $0 [OPTIONS] [arg]
OPTIONS:
=======
 -h | --help                  show usage
 -n | --namespace             provide the kubernetes namespace where the zen component is located
=======
Sample Command: ./lite_adm_apply.sh -n zen
USAGE
}

while [ -n "$1" ]
do
   case $1 in
      -h|--help)
         usage >&2
            exit 0
            ;;
      -n|--namespace)
         NAMESPACE=$2
         log_info "namespace is set to ${NAMESPACE}"
         shift 2
         ;;
      *)
         log_error "Unknown option: $1"
         usage >&2
         exit 1
         ;;
   esac
done

# manually apply lite adm resources
oc apply -f adm/scc/cpd-user-scc.yaml
oc label --overwrite SecurityContextConstraints cpd-user-scc cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/scc/cpd-zensys-scc.yaml
oc label --overwrite SecurityContextConstraints cpd-zensys-scc cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/scc/cpd-noperm-scc.yaml
oc label --overwrite SecurityContextConstraints cpd-noperm-scc cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/sa/cpd-viewer-sa.yaml
oc label --overwrite ServiceAccount cpd-viewer-sa cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/sa/cpd-editor-sa.yaml
oc label --overwrite ServiceAccount cpd-editor-sa cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/sa/cpd-admin-sa.yaml
oc label --overwrite ServiceAccount cpd-admin-sa cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/sa/cpd-norbac-sa.yaml
oc label --overwrite ServiceAccount cpd-norbac-sa cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/rb/cpd-admin-rb.yaml
oc label --overwrite RoleBinding cpd-admin-rb cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/rb/cpd-editor-rb.yaml
oc label --overwrite RoleBinding cpd-editor-rb cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/rb/cpd-viewer-rb.yaml
oc label --overwrite RoleBinding cpd-viewer-rb cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/roles/cpd-admin-role.yaml
oc label --overwrite Role cpd-admin-role cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc apply -f adm/roles/cpd-viewer-role.yaml
oc label --overwrite Role cpd-viewer-role cpd_module=lite-adm-setup cpd_module_arch=x86_64 cpd_module_version=3.5.2
oc adm policy add-scc-to-user cpd-user-scc system:serviceaccount:zen:cpd-viewer-sa
oc adm policy add-scc-to-user cpd-user-scc system:serviceaccount:zen:cpd-editor-sa
oc adm policy add-scc-to-user cpd-zensys-scc system:serviceaccount:zen:cpd-admin-sa
oc adm policy add-scc-to-user cpd-noperm-scc system:serviceaccount:zen:cpd-norbac-sa

# extra sa
oc adm policy add-cluster-role-to-user system:controller:persistent-volume-binder system:serviceaccount:{{NAMESPACE}}:zen-databases-sa

log_passed "Lite adm resources have been applied, you can use cpd-cli now."
exit 0
